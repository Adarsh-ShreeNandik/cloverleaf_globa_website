<style>
  .row.gy-4.abut-row-gy-4 {
    display: flex;
    flex-wrap: wrap;
    flex-direction: column-reverse;
}
h3.color-txt{
  font-size: 2.75rem;
  color: #009649;
}
.col-lg-6.position-relative.align-self-start.order-lg-last.order-first.col-full-width {
  width: 100%;
    display: flex;
    justify-content: space-around;

}
.col-lg-6.content.order-last.order-lg-first.col-full-width {
    width: 100%;
   
    /* padding-top: 15px; */
}

.ul-none {
  margin-top: 10px;
padding-bottom: 15px;
}

.ul-none li {
    list-style: none;
    /* padding-top:10px; */
}
.col-lg-6.content.order-last.order-lg-first.col-full-width.bprder-div {
    border: 1px solid blue;
    border-radius: 30px;
    margin-top: 25px;
    background: #2424a5;
    color: #fff;
    font-size: 1.3rem;
    padding: 18px;
}

h3.color-txt.hpadding {
    padding: 50px 0;
}
h3.color-txt.pd-top {
    padding-top: 20px;
}
section#about {
    padding: 0px 0;
}
.section-header {
    text-align: center;
    padding: 20px 0;
    position: relative;
    margin-top: 20px;
}
.section-header span {
    top: 35px;

}

.features .features-item .ul-none li {
    list-style: none;
    padding-bottom: 0px!important;
}

.txt-colp {
    font-size: 18px;
    line-height: 24px;
    color: #777777;
    width: 100%;
}

.section-header .txt-center p{
  text-align:center;
 }
 .p-text p{
  font-size: 15px;
    font-weight: 700;
 }
 .col-md-4.width-video {
    width: 100% !important;
}
  iframe {
    width: 100% !important;
}

</style>
<main id="main">

    <!-- ======= Breadcrumbs ======= -->
    <div class="breadcrumbs">
       <div class="page-header d-flex align-items-center" style="background-image: url('<?=base_url("assets/img/bg.jpg");?>');">
          <div class="container position-relative">
              <div class="row d-flex justify-content-center">
                  <div class="col-lg-6 text-center p-text">
                      <h2>Blog</h2>
                      <!-- <p>Cloverleaf support for any of its client is based on principles of trust</p> -->
                  </div>
              </div>
          </div>
        </div>
         <nav>
               <div class="container">
                     <ol>
                         <li><a href="index.html">Home</a></li>
                          <li>Blog</li>
                      </ol>
                </div>
          </nav>
    </div><!-- End Breadcrumbs -->

 <!-- ======= About Us Section ======= -->
<!-- ------------------------------------------------------------------------------------------------- -->
 <!-- ---------------------------------------------------------------------------------------- -->






 <section id="features" class="features">
    <div class="container">

      <div class="section-header">

         <span>Folder Gluer under TruCare Maintenance</span>
         <h2>Folder Gluer under TruCare Maintenance</h2>

      </div>

       <div class="row gy-4 align-items-center features-item abut-row-gy-4" data-aos="fade-up">
         
          <div class="col-md-12 col-lg-6 txt-colp">
          <p>
          Lorem ipsum dolor, sit amet consectetur adipisicing elit. Quisquam quos molestias, laboriosam saepe repellendus explicabo exercitationem modi error odio delectus tenetur a. Esse ipsa eaque nihil incidunt fugiat repudiandae ab, deserunt eum placeat tempora deleniti temporibus libero culpa cumque totam.
          </p>
           
          </div>
          <div class="col-md-4 width-video">
            <div class="video-container">
                <iframe class="video-width" width="560" height="315" src="<?=base_url("assets/img/machinedemo.mp4"); ?>" frameborder="0" allowfullscreen></iframe>
            </div>
            <!-- <div class=" col-md-12 col-lg-6">
                <img src="<?=base_url("assets/img/up4.webp"); ?>" class="img-fluid" alt="">
          </div> -->
        </div>

        </div>
    
     

       
    </div>



  

  </section>





 <!-- ---------------------------------------------------------------------------------------- -->



 
 <!-- RRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRR -->




</main>
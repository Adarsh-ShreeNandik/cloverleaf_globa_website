
<main id="main">

    <!-- ======= Breadcrumbs ======= -->
    <div class="breadcrumbs">
        <div class="page-header d-flex align-items-center" style="background-image: url('assets/img/bg.jpg');">
        <div class="container position-relative">
            <div class="row d-flex justify-content-center">
            <div class="col-lg-6 text-center">
                <h2>Truechaul</h2>
                <!-- <p class=" ABOUT1"> Standards for the Packaging and Converting Industry.
                Widely said interchangeably as the Fourth Industrial Revolution, Industry 4.0 at its core refers to the “smart”</p> -->
            </div>
            </div>
        </div>
        </div>
        <nav>
        <div class="container">
            <ol>
            <li><a href="index.html">Home</a></li>
            <li>Truehaul</li>
            </ol>
        </div>
        </nav>
    </div><!-- End Breadcrumbs -->
    <br>
    <br>

    <iframe src="<?=base_url('assets/services/TruHaul.pdf'); ?>" style="width:1500px; height: 100%" frameborder="0" ></iframe>
</Main>